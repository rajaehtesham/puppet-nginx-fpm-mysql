# Vagrant-Puppet

The result of me playing around with Vagrant and Puppet.
